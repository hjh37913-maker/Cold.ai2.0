package com.coldai.assistant.notify

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.CopyOnWriteArrayList

object ColdNotificationListener {
    data class Item(val app: String, val title: String)
    private val items = CopyOnWriteArrayList<Item>()
    fun snapshot(): List<Item> = items.toList()
    fun update(sbn: StatusBarNotification) {
        val e = sbn.notification.extras
        val title = e.getCharSequence("android.title")?.toString()?.trim().orEmpty()
        if (title.isNotBlank()) {
            items.removeAll { it.app == sbn.packageName && it.title == title }
            items.add(0, Item(sbn.packageName.substringAfterLast('.'), title.take(160)))
            while (items.size > 30) items.removeAt(items.lastIndex)
        }
    }
    fun remove(sbn: StatusBarNotification) {
        val e = sbn.notification.extras
        val title = e.getCharSequence("android.title")?.toString()?.trim().orEmpty()
        items.removeAll { it.app == sbn.packageName && it.title == title }
    }
}

class ColdNotificationService : NotificationListenerService() {
    override fun onListenerConnected() {
        activeNotifications?.forEach { ColdNotificationListener.update(it) }
    }
    override fun onNotificationPosted(sbn: StatusBarNotification) { ColdNotificationListener.update(sbn) }
    override fun onNotificationRemoved(sbn: StatusBarNotification) { ColdNotificationListener.remove(sbn) }
}
