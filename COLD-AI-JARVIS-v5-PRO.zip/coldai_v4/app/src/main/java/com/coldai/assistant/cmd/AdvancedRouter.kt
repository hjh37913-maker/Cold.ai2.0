package com.coldai.assistant.cmd

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.Settings
import com.coldai.assistant.R
import com.coldai.assistant.notify.ColdNotificationListener
import java.text.DateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/**
 * Advanced local task layer. It deliberately executes only reversible/safe local actions.
 * Destructive or privacy-sensitive actions remain behind the existing Confirm flow.
 */
object AdvancedRouter {
    private val sep = Regex("\\s+(?:і|и|та|а потім|потом|then|and then)\\s+", RegexOption.IGNORE_CASE)
    private val open = Regex("^(?:відкрий|відкрити|запусти|запустити|открой|открыть|запусти)\\s+(.+)$", RegexOption.IGNORE_CASE)

    fun tryHandle(ctx: Context, raw: String): Cmd? {
        val clean = raw.trim().replace(Regex("^колд[,!.:\\s]+", RegexOption.IGNORE_CASE), "").trim()
        if (clean.isBlank()) return Reply(ctx.getString(R.string.cmd_ok))

        // Multi-step command: "відкрий YouTube і потім відкрий Wi-Fi".
        val parts = clean.split(sep).map { it.trim() }.filter { it.isNotBlank() }
        if (parts.size >= 2 && parts.size <= 6) {
            val steps = parts.mapNotNull { safeSingle(ctx, it) }
            if (steps.size == parts.size && steps.all { it is Reply }) return Sequence(steps)
        }

        // Timed task / alarm: "таймер 5 хв", "постав таймер на 30 секунд".
        Regex("(?:таймер|timer)\\s+(?:на\\s+)?(\\d+)\\s*(сек|секунд|seconds?|s|хв|хвилин|мин|minutes?|m|год|годин|hours?|h)", RegexOption.IGNORE_CASE)
            .find(clean)?.let { m ->
                val n = m.groupValues[1].toLongOrNull() ?: return@let
                val unit = m.groupValues[2].lowercase()
                val sec = when {
                    unit.startsWith("с") || unit == "s" -> n
                    unit.startsWith("х") || unit.startsWith("м") || unit == "m" -> n * 60
                    else -> n * 3600
                }.coerceIn(1, 24 * 3600)
                val i = Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, sec.toInt())
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                return start(ctx, i, "Таймер запущено.")
            }

        // Alarm in 24h notation: "будильник 07:30".
        Regex("(?:будильник|будильник на|alarm)\\s+(\\d{1,2})[:.](\\d{2})(?:\\s+(.+))?", RegexOption.IGNORE_CASE)
            .find(clean)?.let { m ->
                val h = m.groupValues[1].toIntOrNull() ?: return@let
                val min = m.groupValues[2].toIntOrNull() ?: return@let
                if (h !in 0..23 || min !in 0..59) return@let
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, h)
                    .putExtra(AlarmClock.EXTRA_MINUTES, min)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, m.groupValues[3].ifBlank { "COLD" })
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                return start(ctx, i, "Будильник підготовлено.")
            }

        // Calendar event: opens the native event editor with parsed title/time.
        Regex("(?:додай|створи|заплануй|добавь|создай)\\s+(?:подію|событие|зустріч|встречу)\\s+(.+)", RegexOption.IGNORE_CASE)
            .find(clean)?.let { m ->
                val title = m.groupValues[1].trim()
                val i = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, title)
                return start(ctx, i, "Відкриваю створення події: $title")
            }

        // Web search: no API key needed.
        Regex("(?:пошукай|знайди в інтернеті|знайди в гуглі|поищи|найди)\\s+(.+)", RegexOption.IGNORE_CASE)
            .find(clean)?.let { m ->
                val q = Uri.encode(m.groupValues[1].trim())
                return start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$q")), "Відкриваю пошук.")
            }

        // YouTube/music query.
        Regex("(?:включи|увімкни|відкрий|відкрити|запусти|знайди)\\s+(?:на\\s+)?(?:youtube|ютуб)\\s*(.*)", RegexOption.IGNORE_CASE)
            .find(clean)?.let { m ->
                val q = m.groupValues[1].trim()
                val uri = if (q.isBlank()) "https://www.youtube.com" else "https://www.youtube.com/results?search_query=${Uri.encode(q)}"
                return start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(uri)), "Відкриваю YouTube.")
            }

        // Professional device controls / utilities.
        if (Regex("(?:відкрий|відкрити|покажи|перейди в)\s+(?:інформацію про застосунок|app info)", RegexOption.IGNORE_CASE).containsMatchIn(clean)) {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:${ctx.packageName}"))
            return start(ctx, i, "Відкриваю інформацію про COLD AI.")
        }
        val directSetting = when {
            Regex("(?:відкрий|перейди в)\s+(?:місцезнаходження|геолокацію|location)", RegexOption.IGNORE_CASE).containsMatchIn(clean) -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            Regex("(?:відкрий|перейди в)\s+(?:сповіщення|notifications)", RegexOption.IGNORE_CASE).containsMatchIn(clean) -> Settings.ACTION_NOTIFICATION_SETTINGS
            Regex("(?:відкрий|перейди в)\s+(?:дозволи|permissions)", RegexOption.IGNORE_CASE).containsMatchIn(clean) -> Settings.ACTION_APPLICATION_DETAILS_SETTINGS
            Regex("(?:відкрий|перейди в)\s+(?:батарею|battery)", RegexOption.IGNORE_CASE).containsMatchIn(clean) -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            Regex("(?:відкрий|перейди в)\s+(?:доступність|accessibility)", RegexOption.IGNORE_CASE).containsMatchIn(clean) -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            Regex("(?:відкрий|перейди в)\s+(?:режим не турбувати|не турбувати|do not disturb)", RegexOption.IGNORE_CASE).containsMatchIn(clean) -> Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS
            else -> null
        }
        if (directSetting != null) {
            val i = if (directSetting == Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                Intent(directSetting).setData(Uri.parse("package:${ctx.packageName}")) else Intent(directSetting)
            return start(ctx, i, "Відкриваю системні налаштування.")
        }

        if (Regex("(?:відкрий|запусти)\s+(?:камеру|camera)", RegexOption.IGNORE_CASE).containsMatchIn(clean))
            return start(ctx, Intent("android.media.action.IMAGE_CAPTURE"), "Відкриваю камеру.")
        if (Regex("(?:відкрий|покажи)\s+(?:галерею|фото|photos)", RegexOption.IGNORE_CASE).containsMatchIn(clean))
            return start(ctx, Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse("content://media/internal/images/media"), "image/*"), "Відкриваю фото.")
        if (Regex("(?:відкрий|запусти)\s+(?:календар|calendar)", RegexOption.IGNORE_CASE).containsMatchIn(clean))
            return start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("content://com.android.calendar/time/${System.currentTimeMillis()}")), "Відкриваю календар.")
        if (Regex("(?:відкрий|запусти)\s+(?:контакти|contacts)", RegexOption.IGNORE_CASE).containsMatchIn(clean))
            return start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("content://contacts/people")), "Відкриваю контакти.")
        if (Regex("(?:відкрий|запусти)\s+(?:годинник|clock)", RegexOption.IGNORE_CASE).containsMatchIn(clean))
            return start(ctx, Intent(AlarmClock.ACTION_SHOW_ALARMS), "Відкриваю будильники.")

        Regex("(?:скопіюй|скопировать|copy)\s+(.+)", RegexOption.IGNORE_CASE).find(clean)?.let { m ->
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("COLD", m.groupValues[1]))
            return Reply("Скопійовано в буфер обміну.")
        }
        if (Regex("(?:прочитай|покажи)\s+(?:буфер|буфер обміну|clipboard)", RegexOption.IGNORE_CASE).containsMatchIn(clean)) {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            return Reply(cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString()?.take(2000) ?: "Буфер обміну порожній.")
        }
        Regex("(?:поділись|поділитися|share)\s+(.+)", RegexOption.IGNORE_CASE).find(clean)?.let { m ->
            val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, m.groupValues[1])
            return try { ctx.startActivity(Intent.createChooser(i, "Поділитися").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); Reply("Відкриваю меню поширення.") } catch (_: Exception) { Reply("Не вдалося відкрити поширення.") }
        }

        // Natural-language volume / brightness shortcuts.
        Regex("(?:встанови|постав|set)\s+(?:гучність|volume)\s+(\d{1,3})%", RegexOption.IGNORE_CASE).find(clean)?.let { m ->
            val n=m.groupValues[1].toIntOrNull()?.coerceIn(0,100) ?: return@let
            val am=ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            val max=am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
            am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, (max*n/100f).roundToInt(), android.media.AudioManager.FLAG_SHOW_UI)
            return Reply("Гучність встановлено на $n відсотків.")
        }
        if (Regex("(?:збільш|зменш|налаштуй)\s+(?:яскравість|brightness)", RegexOption.IGNORE_CASE).containsMatchIn(clean))
            return start(ctx, Intent(Settings.ACTION_DISPLAY_SETTINGS), "Відкриваю налаштування яскравості.")

        // Quick system panels.
        val panel = when {
            Regex("(?:панель|налаштування)\\s+(?:wi[- ]?fi|вайфай|wifi)", RegexOption.IGNORE_CASE).containsMatchIn(clean) -> Settings.ACTION_WIFI_SETTINGS
            Regex("(?:панель|налаштування)\\s+(?:bluetooth|блютуз)", RegexOption.IGNORE_CASE).containsMatchIn(clean) -> Settings.ACTION_BLUETOOTH_SETTINGS
            Regex("(?:панель|налаштування)\\s+(?:звук|гучність|sound)", RegexOption.IGNORE_CASE).containsMatchIn(clean) -> Settings.ACTION_SOUND_SETTINGS
            Regex("(?:панель|налаштування)\\s+(?:екран|дисплей|display)", RegexOption.IGNORE_CASE).containsMatchIn(clean) -> Settings.ACTION_DISPLAY_SETTINGS
            else -> null
        }
        if (panel != null) return start(ctx, Intent(panel), "Відкриваю системну панель.")

        if (Regex("(?:відкрий|запусти)\s+(?:телефон|dialer|набір номера)", RegexOption.IGNORE_CASE).containsMatchIn(clean))
            return start(ctx, Intent(Intent.ACTION_DIAL), "Відкриваю телефон.")
        if (Regex("(?:відкрий|запусти)\s+(?:повідомлення|sms|messages)", RegexOption.IGNORE_CASE).containsMatchIn(clean))
            return start(ctx, Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING), "Відкриваю повідомлення.")

        // Notification intelligence: uses only notifications explicitly exposed by Android's listener service.
        if (Regex("(?:які|яка)\\s+(?:в мене )?(?:сповіщення|уведомления|повідомлення)|прочитай сповіщення|що нового в сповіщеннях", RegexOption.IGNORE_CASE).containsMatchIn(clean)) {
            val n = ColdNotificationListener.snapshot()
            if (n.isEmpty()) return Reply("Нових доступних сповіщень немає або доступ до них не ввімкнено.")
            return Reply("Ось останні сповіщення:\n" + n.take(6).joinToString("\n") { "• ${it.app}: ${it.title}" })
        }
        if (Regex("увімкни доступ до сповіщень|доступ до сповіщень|доступ к уведомлениям", RegexOption.IGNORE_CASE).containsMatchIn(clean)) {
            return start(ctx, Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"), "Відкриваю доступ до сповіщень.")
        }

        return null
    }

    private fun safeSingle(ctx: Context, text: String): Cmd? {
        val t = text.trim()
        if (open.matches(t)) {
            val name = open.find(t)?.groupValues?.get(1)?.trim().orEmpty()
            if (name.equals("wifi", true) || name.contains("wi-fi", true) || name.contains("вайфай", true))
                return start(ctx, Intent(Settings.ACTION_WIFI_SETTINGS), "Відкриваю Wi-Fi.")
            if (name.contains("bluetooth", true) || name.contains("блютуз", true))
                return start(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS), "Відкриваю Bluetooth.")
            if (name.contains("налаштування", true) || name.contains("настройки", true))
                return start(ctx, Intent(Settings.ACTION_SETTINGS), "Відкриваю налаштування.")
            val pm = ctx.packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val hit = apps.firstOrNull { it.loadLabel(pm).toString().equals(name, true) }
                ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(name, true) }
            val launch = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
            if (launch != null) return start(ctx, launch, "Відкриваю $name.")
        }
        return null
    }

    private fun start(ctx: Context, intent: Intent, ok: String): Cmd = try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        Reply(ok)
    } catch (_: ActivityNotFoundException) {
        Reply("Не знайшов потрібний системний екран або застосунок.")
    } catch (_: Exception) {
        Reply("Не вдалося виконати цю дію на цьому пристрої.")
    }
}
