package com.coldai.assistant.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val ColdDark = darkColorScheme(
    primary = Color(0xFFE8E8E3), onPrimary = Color(0xFF111210),
    primaryContainer = Color(0xFF2A2C29), onPrimaryContainer = Color(0xFFF1F1EC),
    secondary = Color(0xFFB7B9B2), onSecondary = Color(0xFF151613),
    secondaryContainer = Color(0xFF292B28), onSecondaryContainer = Color(0xFFE3E4DE),
    tertiary = Color(0xFFBFC0BA), onTertiary = Color(0xFF151613),
    background = Color(0xFF080A10), onBackground = Color(0xFFF3F4F8),
    surface = Color(0xFF10131B), onSurface = Color(0xFFF3F4F8),
    surfaceVariant = Color(0xFF171B25), onSurfaceVariant = Color(0xFFA8AFBF),
    outline = Color(0xFF2C3342), outlineVariant = Color(0xFF202632),
    error = Color(0xFFFF8A80), onError = Color(0xFF2A0A07)
)

private val ColdLight = lightColorScheme(
    primary = Color(0xFF3F403C), onPrimary = Color.White,
    primaryContainer = Color(0xFFE6E7E1), onPrimaryContainer = Color(0xFF20211E),
    secondary = Color(0xFF565852), onSecondary = Color.White,
    secondaryContainer = Color(0xFFE3E4DE), onSecondaryContainer = Color(0xFF20211E),
    tertiary = Color(0xFF666861), onTertiary = Color.White,
    background = Color(0xFFF7F8FC), onBackground = Color(0xFF171922),
    surface = Color(0xFFFFFFFF), onSurface = Color(0xFF171922),
    surfaceVariant = Color(0xFFF0F1F7), onSurfaceVariant = Color(0xFF606574),
    outline = Color(0xFFD7D9E3), outlineVariant = Color(0xFFE6E7ED),
    error = Color(0xFFC92F45), onError = Color.White
)

private val ColdTypography = Typography(
    displaySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 34.sp, letterSpacing = (-1.0).sp),
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 30.sp, letterSpacing = (-0.6).sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 24.sp, letterSpacing = (-0.35).sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 19.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 25.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 13.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 11.sp)
)

@Composable
fun ColdTheme(mode: String, content: @Composable () -> Unit) {
    val dark = when (mode) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) ColdDark else ColdLight, typography = ColdTypography, content = content)
}
