package com.coldai.assistant.cmd

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent
import com.coldai.assistant.R
import java.text.DateFormat
import java.util.Date
import java.util.Random
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

sealed interface Cmd
data class Reply(val text: String) : Cmd
data class Remember(val fact: String) : Cmd
data class Sequence(val steps: List<Cmd>) : Cmd
/** Действие, требующее подтверждения. perms — разрешения, которые нужно получить перед выполнением. */
class Confirm(val prompt: String, val perms: List<String>, val run: () -> String) : Cmd
object PassToAi : Cmd

/**
 * Локальный разбор команд. Всё, что не распознано, уходит в Gemini.
 * Звонки и SMS выполняются только после подтверждения и наличия разрешений.
 */
object CommandRouter {
    private const val OPEN = "открой|открыть|відкрий|відкрити|запусти|запустити"
    private val rnd = Random()

    private fun r(p: String) = Regex(p, RegexOption.IGNORE_CASE)

    fun handle(ctx: Context, raw: String): Cmd {
        val advanced = AdvancedRouter.tryHandle(ctx, raw)
        if (advanced != null) return advanced
        val c = raw.trim().replace(r("^колд[,!.:\\s]+"), "").trim().trimEnd('.', '!', '?').trim()
        val t = c.lowercase()
        val locale = ctx.resources.configuration.locales[0]

        // 1. Запомни
        r("^(запомни|запам['’ʼ]?ятай)[,:]?\\s+(.+)$").find(c)?.let { return Remember(it.groupValues[2].trim()) }

        // 2. Время
        if (r("который час|сколько времени|скільки часу|котра година|яка зараз година").containsMatchIn(t))
            return Reply(ctx.getString(R.string.cmd_time, DateFormat.getTimeInstance(DateFormat.SHORT, locale).format(Date())))

        // 3. Дата
        if (r("какое сегодня число|какая сегодня дата|какое число|какой сегодня день|яка сьогодні дата|яке сьогодні число|який сьогодні день").containsMatchIn(t))
            return Reply(ctx.getString(R.string.cmd_date, DateFormat.getDateInstance(DateFormat.FULL, locale).format(Date())))

        // 4–7. Музыка
        val opt = "( музыку| музику| трек| песню| пісню)?"
        when {
            r("^(поставь на паузу|постав на паузу|пауза|стоп|останови|зупини)$opt$").matches(t) -> return media(ctx, KeyEvent.KEYCODE_MEDIA_PAUSE)
            r("^(играй|продолжи|воспроизведи|грай|продовжи|відтвори)$opt$").matches(t) -> return media(ctx, KeyEvent.KEYCODE_MEDIA_PLAY)
            r("^(следующий трек|следующая песня|наступний трек|наступна пісня|дальше)$").matches(t) -> return media(ctx, KeyEvent.KEYCODE_MEDIA_NEXT)
            r("^(предыдущий трек|предыдущая песня|попередній трек|попередня пісня)$").matches(t) -> return media(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        }

        // 8. Гучність
        if (r("(збільш|підвищ|увеличь|прибавь).*(гучність|звук)|громче|гучніше").containsMatchIn(t)) {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            return Reply(ctx.getString(R.string.cmd_ok))
        }
        if (r("(зменш|знизь|убавь|зроби тихіше).*(гучність|звук)|тише|тихіше").containsMatchIn(t)) {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            return Reply(ctx.getString(R.string.cmd_ok))
        }
        if (r("вимкни звук|выключи звук|беззвучний|беззвучный|mute").containsMatchIn(t)) {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustVolume(AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            return Reply(ctx.getString(R.string.cmd_ok))
        }

        // 9. Системний статус
        if (r("стан системи|статус системи|статус системы|состояние системы|system status").containsMatchIn(t)) {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val online = try {
                val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
                cm.activeNetwork != null
            } catch (_: Exception) { false }
            return Reply("Система готова. Батарея $pct відсотків. Мережа: ${if (online) "онлайн" else "офлайн"}.")
        }

        // 10. Відміна / зупинка асистента
        if (r("^(скасуй|відміни|отмени|отмена|стоп асистент|зупинись|остановись)$").matches(t))
            return Reply(ctx.getString(R.string.cancelled))

        // 8. Батарея
        if (r("заряд|батаре|battery|рівень батареї|скільки заряд").containsMatchIn(t)) {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val status = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val charging = status?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) == BatteryManager.BATTERY_STATUS_CHARGING
            val extra = if (charging) ctx.getString(R.string.cmd_charging) else ""
            return Reply(ctx.getString(R.string.cmd_battery, pct) + extra)
        }

        // 9–11. Громкость
        when {
            r("^(громче|увеличь громкость|збільш гучність|volume up)$").matches(t) -> {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                return Reply(ctx.getString(R.string.cmd_ok))
            }
            r("^(тише|уменьши громкость|зменш гучність|volume down)$").matches(t) -> {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                return Reply(ctx.getString(R.string.cmd_ok))
            }
            r("^(без звука|выключи звук|mute|вимкни звук|тишина)$").matches(t) -> {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                return Reply(ctx.getString(R.string.cmd_ok))
            }
            r("^(включи звук|unmute|увімкни звук)$").matches(t) -> {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
                return Reply(ctx.getString(R.string.cmd_ok))
            }
        }

        // 12. Фонарик
        r("^(включи|выключи|увімкни|вимкни)\\s+(фонарик|ліхтарик|flashlight)$").find(t)?.let {
            val on = it.groupValues[1].contains("включ") || it.groupValues[1].contains("увімк")
            return try {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.firstOrNull() ?: return Reply(ctx.getString(R.string.cmd_no_flash))
                cm.setTorchMode(id, on)
                Reply(ctx.getString(R.string.cmd_ok))
            } catch (e: Exception) {
                Reply(ctx.getString(R.string.cmd_no_flash))
            }
        }
        if (r("^(фонарик|ліхтарик)$").matches(t)) {
            return try {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.firstOrNull() ?: return Reply(ctx.getString(R.string.cmd_no_flash))
                cm.setTorchMode(id, true)
                Reply(ctx.getString(R.string.cmd_ok))
            } catch (e: Exception) {
                Reply(ctx.getString(R.string.cmd_no_flash))
            }
        }

        // 13. Информация об устройстве
        if (r("информация об устройстве|о телефоне|модель телефона|інформація про пристрій|про телефон").containsMatchIn(t)) {
            val info = "${Build.MANUFACTURER} ${Build.MODEL}\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
            return Reply(info)
        }

        // 14. Калькулятор (простое выражение)
        r("^(посчитай|вычисли|порахуй|скільки буде|calculate)\\s+(.+)$").find(c)?.let {
            val expr = it.groupValues[2].replace(',', '.').replace(Regex("[^0-9.+\\-*/()\\s]"), "")
            return try {
                val result = evalSimple(expr)
                Reply(ctx.getString(R.string.cmd_calc, result))
            } catch (e: Exception) {
                Reply(ctx.getString(R.string.cmd_calc_fail))
            }
        }
        // чистое математическое выражение
        if (t.matches(Regex("^[0-9.+\\-*/()\\s,]+$")) && t.any { it in "+-*/" }) {
            val expr = c.replace(',', '.')
            return try {
                val result = evalSimple(expr)
                Reply(ctx.getString(R.string.cmd_calc, result))
            } catch (e: Exception) {
                PassToAi
            }
        }

        // 15. Монетка
        if (r("подбрось монетку|подкинь монету|орёл или решка|монетка|підкинь монету|орел чи решка").containsMatchIn(t)) {
            val side = if (rnd.nextBoolean()) ctx.getString(R.string.cmd_heads) else ctx.getString(R.string.cmd_tails)
            return Reply(side)
        }

        // 16. Кубик
        r("^(брось|кинь|кинь|кинути)\\s*(кубик|dice|d(\\d+))?$").find(t)?.let {
            val sides = it.groupValues.getOrNull(3)?.toIntOrNull() ?: 6
            val n = rnd.nextInt(sides.coerceIn(2, 100)) + 1
            return Reply(ctx.getString(R.string.cmd_dice, n, sides))
        }
        if (r("^(кубик|dice)$").matches(t)) {
            return Reply(ctx.getString(R.string.cmd_dice, rnd.nextInt(6) + 1, 6))
        }

        // 17. Случайное число
        r("^(случайное число|рандом|random|випадкове число)\\s*(от\\s+(\\d+)\\s+до\\s+(\\d+)|від\\s+(\\d+)\\s+до\\s+(\\d+))?$").find(t)?.let {
            val a = it.groupValues.getOrNull(3)?.toIntOrNull() ?: it.groupValues.getOrNull(5)?.toIntOrNull() ?: 1
            val b = it.groupValues.getOrNull(4)?.toIntOrNull() ?: it.groupValues.getOrNull(6)?.toIntOrNull() ?: 100
            val lo = minOf(a, b); val hi = maxOf(a, b)
            return Reply(ctx.getString(R.string.cmd_random, rnd.nextInt(hi - lo + 1) + lo))
        }

        // 18. Генератор пароля
        if (r("сгенерируй пароль|придумай пароль|generate password|згенеруй пароль").containsMatchIn(t)) {
            val chars = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%"
            val pass = (1..12).map { chars[rnd.nextInt(chars.length)] }.joinToString("")
            // копируем в буфер
            (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("password", pass))
            return Reply(ctx.getString(R.string.cmd_password, pass))
        }

        // 19. Поиск Google
        r("^(найди|поищи|search|знайди|пошукай)\\s+(?:в\\s+)?(?:google|гугл)?\\s*(.+)$").find(c)?.let {
            val q = Uri.encode(it.groupValues[2].trim())
            return startSafely(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$q")))
        }

        // 20. Поиск Яндекс
        r("^(найди|поищи|знайди)\\s+(?:в\\s+)?(?:яндекс|yandex)\\s+(.+)$").find(c)?.let {
            val q = Uri.encode(it.groupValues[2].trim())
            return startSafely(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://yandex.ru/search/?text=$q")))
        }

        // 21. Открыть камеру
        if (r("открой камеру|открой фотоаппарат|відкрий камеру|запусти камеру").containsMatchIn(t))
            return startSafely(ctx, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))

        // 22. Открыть галерею
        if (r("открой галерею|открой фото|відкрий галерею|відкрий фото").containsMatchIn(t))
            return startSafely(ctx, Intent(Intent.ACTION_VIEW).setType("image/*"))

        // 23. Открыть контакты
        if (r("открой контакты|открой телефонную книгу|відкрий контакти").containsMatchIn(t))
            return startSafely(ctx, Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI))

        // 24. Открыть календарь
        if (r("открой календарь|відкрий календар").containsMatchIn(t))
            return startSafely(ctx, Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR))

        // 25. Будильник
        r("^(поставь|установи|постав|встанови)\\s+(?:будильник|alarm)\\s+(?:на\\s+)?(\\d{1,2})[:\\.](\\d{2})$").find(t)?.let {
            val h = it.groupValues[1].toInt().coerceIn(0, 23)
            val m = it.groupValues[2].toInt().coerceIn(0, 59)
            val intent = Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, m)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            return startSafely(ctx, intent)
        }
        if (r("открой будильник|відкрий будильник").containsMatchIn(t))
            return startSafely(ctx, Intent(AlarmClock.ACTION_SHOW_ALARMS))

        // 26. Таймер
        r("^(поставь|установи|постав|встанови)\\s+(?:таймер|timer)\\s+(?:на\\s+)?(\\d+)\\s*(минут|хвилин|мин|хв|секунд|сек|s|m)?$").find(t)?.let {
            val n = it.groupValues[1].toInt().coerceIn(1, 3600)
            val unit = it.groupValues[2].lowercase()
            val sec = if (unit.startsWith("с") || unit == "s") n else n * 60
            val intent = Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, sec)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            return startSafely(ctx, intent)
        }

        // 27. Email
        r("^(напиши|отправь|надішли)\\s+(?:письмо|email|емейл|пошту)\\s+(.+)$").find(c)?.let {
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).putExtra(Intent.EXTRA_TEXT, it.groupValues[1].trim())
            return startSafely(ctx, intent)
        }
        if (r("открой почту|відкрий пошту").containsMatchIn(t))
            return startSafely(ctx, Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_EMAIL))

        // 28. WhatsApp
        r("^(напиши|отправь|надішли)\\s+(?:в\\s+)?whatsapp\\s+(.+)$").find(c)?.let {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/?text=" + Uri.encode(it.groupValues[1].trim())))
            return startSafely(ctx, intent)
        }
        if (r("открой whatsapp|відкрий whatsapp").containsMatchIn(t))
            return startSafely(ctx, ctx.packageManager.getLaunchIntentForPackage("com.whatsapp")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/")))

        // 29. Карты / место
        r("^(покажи|найди|знайди)\\s+(?:на\\s+)?(?:карте|карті|maps)\\s+(.+)$").find(c)?.let {
            val q = Uri.encode(it.groupValues[2].trim())
            return startSafely(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$q")))
        }
        if (r("открой карты|открой навигатор|відкрий карти|відкрий навігатор").containsMatchIn(t))
            return startSafely(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0")))

        // 30. Копировать в буфер
        r("^(скопируй|скопируй|скопіюй)\\s+(.+)$").find(c)?.let {
            (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("cold", it.groupValues[2].trim()))
            return Reply(ctx.getString(R.string.cmd_copied))
        }

        // Открыть сайт
        r("^(?:$OPEN)\\s+(?:сайт\\s+)?((?:https?://)?[\\p{L}\\d-]+(?:\\.[\\p{L}\\d-]+)+\\S*)$").find(c)?.let {
            val u = it.groupValues[1].let { s -> if (s.startsWith("http", true)) s else "https://$s" }
            return startSafely(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)))
        }

        // Системные настройки
        r("^(?:$OPEN)\\s+(?:системные\\s+)?(?:настройки|налаштування)\\s*(.*)$").find(c)?.let {
            val k = it.groupValues[1].lowercase()
            val action = when {
                k.contains("wi") || k.contains("вай") -> Settings.ACTION_WIFI_SETTINGS
                k.contains("bluetooth") || k.contains("блютуз") -> Settings.ACTION_BLUETOOTH_SETTINGS
                k.contains("звук") -> Settings.ACTION_SOUND_SETTINGS
                k.contains("экран") || k.contains("екран") -> Settings.ACTION_DISPLAY_SETTINGS
                k.contains("приложен") || k.contains("застосун") || k.contains("додат") -> Settings.ACTION_APPLICATION_SETTINGS
                k.contains("батаре") || k.contains("заряд") -> Settings.ACTION_BATTERY_SAVER_SETTINGS
                k.contains("локац") || k.contains("местополож") || k.contains("геолок") -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                k.contains("уведомл") || k.contains("сповіщ") -> Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
                k.contains("язык") || k.contains("мову") -> Settings.ACTION_LOCALE_SETTINGS
                k.contains("дата") || k.contains("время") || k.contains("час") -> Settings.ACTION_DATE_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            return startSafely(ctx, Intent(action))
        }

        // Открыть приложение
        r("^(?:$OPEN)\\s+(?:приложение\\s+|додаток\\s+|застосунок\\s+)?(.+)$").find(c)?.let {
            val name = it.groupValues[1].trim().lowercase()
            val pm = ctx.packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val hit = apps.firstOrNull { a -> a.loadLabel(pm).toString().lowercase() == name }
                ?: apps.firstOrNull { a -> a.loadLabel(pm).toString().lowercase().contains(name) }
            val launch = hit?.let { h -> pm.getLaunchIntentForPackage(h.activityInfo.packageName) }
            return if (launch == null) Reply(ctx.getString(R.string.cmd_app_not_found, it.groupValues[1].trim()))
            else startSafely(ctx, launch)
        }

        // Звонок (с подтверждением)
        r("^(?:позвони|набери|зателефонуй|подзвони|телефонуй)\\s+(.+)$").find(c)?.let {
            val target = it.groupValues[1].trim()
            val num = digits(target)
            val perms = mutableListOf(Manifest.permission.CALL_PHONE)
            if (num == null) perms += Manifest.permission.READ_CONTACTS
            val run: () -> String = {
                val number = num ?: lookup(ctx, target)
                if (number == null) ctx.getString(R.string.contact_not_found, target)
                else {
                    ctx.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    ctx.getString(R.string.cmd_ok)
                }
            }
            return Confirm(ctx.getString(R.string.confirm_call, target), perms, run)
        }

        // SMS (с подтверждением)
        r("^(?:отправь смс|отправь сообщение|надішли смс|надішли повідомлення|смс)\\s+(\\S+)\\s+(.+)$").find(c)?.let {
            val target = it.groupValues[1].trim()
            val body = it.groupValues[2].trim()
            val num = digits(target)
            val perms = mutableListOf(Manifest.permission.SEND_SMS)
            if (num == null) perms += Manifest.permission.READ_CONTACTS
            val run: () -> String = {
                val number = num ?: lookup(ctx, target)
                if (number == null) ctx.getString(R.string.contact_not_found, target)
                else {
                    @Suppress("DEPRECATION")
                    val sms = SmsManager.getDefault()
                    sms.sendMultipartTextMessage(number, null, sms.divideMessage(body), null, null)
                    ctx.getString(R.string.cmd_ok)
                }
            }
            return Confirm(ctx.getString(R.string.confirm_sms, target, body), perms, run)
        }

        return PassToAi
    }

    private fun digits(s: String): String? {
        val d = s.replace(Regex("[\\s()-]"), "")
        return if (d.matches(Regex("\\+?\\d{3,}"))) d else null
    }

    private fun media(ctx: Context, key: Int): Cmd {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
        return Reply(ctx.getString(R.string.cmd_ok))
    }

    private fun startSafely(ctx: Context, i: Intent): Cmd = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        Reply(ctx.getString(R.string.cmd_ok))
    } catch (e: ActivityNotFoundException) {
        Reply(ctx.getString(R.string.cmd_open_fail))
    } catch (e: Exception) {
        Reply(ctx.getString(R.string.cmd_open_fail))
    }

    private fun lookup(ctx: Context, name: String): String? {
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.Contacts.DISPLAY_NAME + " LIKE ?",
            arrayOf("%" + name + "%"), null
        )?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    /** Простой калькулятор: + - * / и скобки. */
    private fun evalSimple(expr: String): String {
        val tokens = tokenize(expr.replace(" ", ""))
        val rpn = toRpn(tokens)
        val stack = ArrayDeque<Double>()
        for (t in rpn) {
            when (t) {
                "+" -> { val b = stack.removeLast(); val a = stack.removeLast(); stack.addLast(a + b) }
                "-" -> { val b = stack.removeLast(); val a = stack.removeLast(); stack.addLast(a - b) }
                "*" -> { val b = stack.removeLast(); val a = stack.removeLast(); stack.addLast(a * b) }
                "/" -> { val b = stack.removeLast(); val a = stack.removeLast(); stack.addLast(a / b) }
                else -> stack.addLast(t.toDouble())
            }
        }
        val v = stack.last()
        return if (v == v.toLong().toDouble()) v.toLong().toString() else ((v * 1000).roundToInt() / 1000.0).toString()
    }

    private fun tokenize(s: String): List<String> {
        val out = mutableListOf<String>()
        var i = 0
        while (i < s.length) {
            when {
                s[i].isDigit() || s[i] == '.' -> {
                    val start = i
                    while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
                    out += s.substring(start, i)
                }
                s[i] in "+-*/()" -> { out += s[i].toString(); i++ }
                else -> i++
            }
        }
        return out
    }

    private fun toRpn(tokens: List<String>): List<String> {
        val out = mutableListOf<String>()
        val ops = ArrayDeque<String>()
        val prec = mapOf("+" to 1, "-" to 1, "*" to 2, "/" to 2)
        for (t in tokens) {
            when {
                t.toDoubleOrNull() != null -> out += t
                t == "(" -> ops.addLast(t)
                t == ")" -> {
                    while (ops.isNotEmpty() && ops.last() != "(") out += ops.removeLast()
                    if (ops.isNotEmpty()) ops.removeLast()
                }
                t in prec -> {
                    while (ops.isNotEmpty() && ops.last() in prec && (prec[ops.last()] ?: 0) >= (prec[t] ?: 0))
                        out += ops.removeLast()
                    ops.addLast(t)
                }
            }
        }
        while (ops.isNotEmpty()) out += ops.removeLast()
        return out
    }
}
