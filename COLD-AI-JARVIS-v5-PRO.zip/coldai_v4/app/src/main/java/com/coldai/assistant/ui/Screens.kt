@file:OptIn(ExperimentalMaterial3Api::class)

package com.coldai.assistant.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.coldai.assistant.R
import com.coldai.assistant.ai.Kind
import com.coldai.assistant.ai.UiError
import com.coldai.assistant.cmd.Confirm
import kotlinx.coroutines.launch

private enum class Screen { HOME, CHAT, FEATURES, MEMORY, SETTINGS }

@Composable private fun ColdLogo(size: androidx.compose.ui.unit.Dp = 44.dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.onSurface), contentAlignment = Alignment.Center) {
        Text("C", color = MaterialTheme.colorScheme.surface, fontWeight = FontWeight.Black, fontSize = (size.value * .43f).sp)
    }
}

@Composable private fun AssistantOrb(status: Status, onClick: () -> Unit) {
    val active = status != Status.IDLE
    val transition = rememberInfiniteTransition(label = "core")
    val pulse by transition.animateFloat(1f, if (active) 1.025f else 1.012f, infiniteRepeatable(tween(if (active) 650 else 1800), RepeatMode.Reverse), label = "pulse")
    Box(Modifier.size(270.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.size(244.dp).border(1.dp, MaterialTheme.colorScheme.outline.copy(.7f), CircleShape))
        Box(Modifier.size(220.dp).border(1.dp, MaterialTheme.colorScheme.outline.copy(.55f), CircleShape))
        Box(Modifier.size(188.dp).graphicsLayer { scaleX = pulse; scaleY = pulse }
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.onSurface)
            .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
            .clickable { onClick() }, contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(if (active) Icons.Default.Close else Icons.Default.Mic, null, Modifier.size(44.dp), tint = MaterialTheme.colorScheme.surface)
                Spacer(Modifier.height(8.dp))
                Text(if (active) status.name else "SPEAK", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.surface.copy(.82f), letterSpacing = 1.5.sp)
            }
        }
    }
}

@Composable private fun HudMetric(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface.copy(.72f), border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(.18f))) {
        Column(Modifier.padding(horizontal = 13.dp, vertical = 9.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Text(value, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable private fun HudHeader(onSettings: () -> Unit, onMemory: () -> Unit) {
    Row(Modifier.fillMaxWidth().widthIn(max = 900.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("COLD // CORE", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            Text("PERSONAL VOICE SYSTEM", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, letterSpacing = 2.sp)
        }
        IconButton(onMemory) { Icon(Icons.Outlined.Memory, "Пам'ять") }
        IconButton(onSettings) { Icon(Icons.Outlined.Settings, "Налаштування") }
    }
}

@Composable private fun StatusText(status: Status) {
    val text = stringResource(when (status) {
        Status.IDLE -> R.string.assistant_ready
        Status.LISTENING -> R.string.status_listening
        Status.THINKING -> R.string.status_thinking
        Status.SPEAKING -> R.string.status_speaking
    })
    Text(text, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable private fun VoiceChip(vm: ColdVm, onOpen: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    Surface(onClick = onOpen, shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surfaceVariant, border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
        Row(Modifier.padding(horizontal = 13.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.RecordVoiceOver, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(7.dp))
            Text(s.voice.ifEmpty { stringResource(R.string.voice_default) }, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.width(3.dp)); Icon(Icons.Default.ExpandMore, null, Modifier.size(17.dp))
        }
    }
}

private data class QuickAction(val icon: androidx.compose.ui.graphics.vector.ImageVector, val label: String, val command: String)

@Composable private fun QuickActions(onRun: (String) -> Unit) {
    val actions = listOf(
        QuickAction(Icons.Default.BatteryStd, "Батарея", "заряд батареи"),
        QuickAction(Icons.Default.Wifi, "Wi‑Fi", "відкрий налаштування Wi-Fi"),
        QuickAction(Icons.Default.FlashlightOn, "Ліхтар", "включи фонарик"),
        QuickAction(Icons.Default.Alarm, "Будильник", "відкрий будильник"),
        QuickAction(Icons.Default.Timer, "Таймер", "постав таймер на 5 хвилин"),
        QuickAction(Icons.Default.Search, "Пошук", "найди в google погоду")
    )
    Column(Modifier.fillMaxWidth().widthIn(max = 720.dp)) {
        Text("Дії", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        androidx.compose.foundation.lazy.grid.LazyVerticalGrid(
            columns = androidx.compose.foundation.lazy.grid.GridCells.Fixed(2),
            modifier = Modifier.height(112.dp), verticalArrangement = Arrangement.spacedBy(6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), userScrollEnabled = false
        ) {
            items(actions.size) { i ->
                val a = actions[i]
                Surface(onClick = { onRun(a.command) }, shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surface, border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
                    Row(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(a.icon, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.width(9.dp)); Text(a.label, style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    }
}

@Composable fun ColdApp(vm: ColdVm, onMic: () -> Unit, onConfirm: (Confirm) -> Unit, onLang: (String) -> Unit) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    ColdTheme(settings.theme) {
        var screen by remember { mutableStateOf(Screen.HOME) }
        var voicePicker by remember { mutableStateOf(false) }
        var text by remember { mutableStateOf("") }
        val drawer = rememberDrawerState(DrawerValue.Closed)
        val scope = rememberCoroutineScope()
        val wide = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp >= 900
        val go = { s: Screen -> screen = s; scope.launch { drawer.close() } }
        val body: @Composable () -> Unit = {
            when (screen) {
                Screen.HOME -> HomeScreen(vm, onMic, { voicePicker = true }, { go(Screen.SETTINGS) }, { go(Screen.MEMORY) }, { vm.send(LocalContext.current, it) })
                Screen.FEATURES -> FeaturesScreen(vm) { go(Screen.HOME) }
                Screen.CHAT -> ChatScreen(vm, { text = it }, onMic)
                Screen.MEMORY -> MemoryScreen(vm) { go(Screen.HOME) }
                Screen.SETTINGS -> SettingsScreen(vm, onLang) { go(Screen.HOME) }
            }
        }
        if (wide) {
            Row(Modifier.fillMaxSize()) { Sidebar(vm, screen, go, Modifier.width(290.dp)); Box(Modifier.weight(1f)) { body() } }
        } else {
            ModalNavigationDrawer(drawerState = drawer, drawerContent = { ModalDrawerSheet { Sidebar(vm, screen, go, Modifier.fillMaxWidth()) } }) {
                Box(Modifier.fillMaxSize()) {
                    body()
                    if (screen != Screen.HOME) IconButton({ scope.launch { drawer.open() } }, Modifier.padding(8.dp)) { Icon(Icons.Default.Menu, stringResource(R.string.menu)) }
                }
            }
        }
        if (voicePicker) VoicePicker(vm) { voicePicker = false }
    }
}

@Composable private fun HomeScreen(vm: ColdVm, onMic: () -> Unit, onVoice: () -> Unit, onSettings: () -> Unit, onMemory: () -> Unit, onRun: (String) -> Unit) {
    val status by vm.status.collectAsStateWithLifecycle()
    val partial by vm.partial.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var time by remember { mutableStateOf("") }
    val battery = remember { ctx.getSystemService(android.content.Context.BATTERY_SERVICE) as android.os.BatteryManager }
    val batteryPct = remember { battery.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) }
    LaunchedEffect(Unit) {
        while (true) {
            time = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
            kotlinx.coroutines.delay(1000)
        }
    }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            HudHeader(onSettings, onMemory)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth().widthIn(max = 900.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HudMetric("SYSTEM", if (status == Status.IDLE) "READY" else status.name, Modifier.weight(1f))
                HudMetric("BATTERY", "$batteryPct%", Modifier.weight(1f))
                HudMetric("TIME", time, Modifier.weight(1f))
                HudMetric("NETWORK", "ONLINE", Modifier.weight(1f))
            }
            Spacer(Modifier.height(18.dp))
            Text("COLD", style = MaterialTheme.typography.displaySmall, textAlign = TextAlign.Center, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Text(StatusTextValue(status), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
            Spacer(Modifier.height(2.dp))
            VoiceChip(vm, onVoice)
            if (partial.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant, border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(.2f))) {
                    Text(partial, Modifier.padding(horizontal = 14.dp, vertical = 9.dp), maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
            Spacer(Modifier.height(2.dp))
            AssistantOrb(status, onMic)
            Text(if (status == Status.LISTENING) "Натисни ще раз, щоб завершити" else "Натисни та говори", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(20.dp))
            QuickActions(onRun)
            if (error != null) {
                Spacer(Modifier.height(12.dp))
                Surface(Modifier.fillMaxWidth().widthIn(max = 720.dp), shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.errorContainer) {
                    Text(errorText(ctx, error!!), Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onErrorContainer)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("VOICE  /  LOCAL  /  AI", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.2.sp)
        }
    }
}

private fun StatusTextValue(status: Status): String = when (status) {
    Status.IDLE -> "SYSTEM READY • чекаю команду"
    Status.LISTENING -> "LISTENING • слухаю тебе"
    Status.THINKING -> "PROCESSING • обробляю запит"
    Status.SPEAKING -> "SPEAKING • відповідаю голосом"
}

private fun errorText(ctx: android.content.Context, e: UiError): String = when (e.kind) {
    Kind.NO_KEY -> ctx.getString(R.string.err_no_key); Kind.NETWORK -> ctx.getString(R.string.err_network); Kind.RATE -> ctx.getString(R.string.err_rate); Kind.MODEL -> ctx.getString(R.string.err_model); Kind.KEY -> ctx.getString(R.string.err_key); Kind.EMPTY -> ctx.getString(R.string.err_empty); Kind.STT -> ctx.getString(R.string.err_stt, e.detail ?: "?"); Kind.PERM -> ctx.getString(R.string.err_perm); else -> ctx.getString(R.string.err_generic) + (e.detail?.let { ": $it" } ?: "")
}

@Composable private fun Sidebar(vm: ColdVm, screen: Screen, go: (Screen) -> Unit, modifier: Modifier) {
    val chats by vm.chats.collectAsStateWithLifecycle(); val current by vm.chatId.collectAsStateWithLifecycle()
    Column(modifier.fillMaxHeight().padding(16.dp)) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) { ColdLogo(40.dp); Spacer(Modifier.width(10.dp)); Column { Text("COLD AI", fontWeight = FontWeight.Bold); Text("VOICE ASSISTANT", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary) } }
        Spacer(Modifier.height(12.dp)); NavButton(Icons.Default.Mic, "Помічник", screen == Screen.HOME) { go(Screen.HOME) }
        NavButton(Icons.Outlined.ChatBubbleOutline, "Чати", screen == Screen.CHAT) { go(Screen.CHAT) }
        NavButton(Icons.Outlined.GridView, "Функції", screen == Screen.FEATURES) { go(Screen.FEATURES) }
        NavButton(Icons.Outlined.Memory, stringResource(R.string.memory), screen == Screen.MEMORY) { go(Screen.MEMORY) }
        Spacer(Modifier.height(14.dp)); Text("ІСТОРІЯ", Modifier.padding(horizontal = 10.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(vertical = 8.dp)) { items(chats, key = { it.id }) { c -> Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (c.id == current) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent).clickable { vm.openChat(c.id); go(Screen.CHAT) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Outlined.ChatBubbleOutline, null, Modifier.size(17.dp)); Spacer(Modifier.width(8.dp)); Text(c.title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis); IconButton({ vm.deleteChat(c.id) }, Modifier.size(28.dp)) { Icon(Icons.Default.Delete, null, Modifier.size(15.dp)) } } } }
        NavButton(Icons.Outlined.Settings, stringResource(R.string.settings), screen == Screen.SETTINGS) { go(Screen.SETTINGS) }
    }
}

@Composable private fun NavButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, selected: Boolean, click: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(if (selected) MaterialTheme.colorScheme.primary.copy(.12f) else Color.Transparent).clickable { click() }.padding(horizontal = 12.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.width(11.dp)); Text(label, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal) }
}


private data class FeatureItem(val group: String, val title: String, val detail: String, val command: String)

@Composable private fun FeaturesScreen(vm: ColdVm, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val groups = listOf(
        "Система" to listOf(
            FeatureItem("Система","Статус пристрою","батарея • мережа • Android","статус системи"),
            FeatureItem("Система","Wi‑Fi","системна панель Wi‑Fi","відкрий налаштування Wi-Fi"),
            FeatureItem("Система","Bluetooth","системна панель Bluetooth","відкрий налаштування Bluetooth"),
            FeatureItem("Система","Звук","керування гучністю","відкрий налаштування звуку"),
            FeatureItem("Система","Дисплей","яскравість та екран","відкрий налаштування дисплея"),
            FeatureItem("Система","Місцезнаходження","системний доступ до Location","відкрий місцезнаходження"),
            FeatureItem("Система","Батарея","режим енергозбереження","відкрий батарею"),
            FeatureItem("Система","Доступність","Android Accessibility","відкрий доступність")
        ),
        "Комунікації" to listOf(
            FeatureItem("Комунікації","Контакти","відкрити контакти","відкрий контакти"),
            FeatureItem("Комунікації","Телефон","дзвінки через системний dialer","відкрий телефон"),
            FeatureItem("Комунікації","SMS","надсилання з підтвердженням","відкрий повідомлення"),
            FeatureItem("Комунікації","Сповіщення","останні доступні сповіщення","які в мене сповіщення"),
            FeatureItem("Комунікації","Календар","створення та перегляд подій","відкрий календар")
        ),
        "Медіа" to listOf(
            FeatureItem("Медіа","Камера","запуск системної камери","відкрий камеру"),
            FeatureItem("Медіа","Фото","відкрити галерею","відкрий галерею"),
            FeatureItem("Медіа","YouTube","пошук голосом","відкрий YouTube"),
            FeatureItem("Медіа","Відтворення","play / pause / next / previous","пауза"),
            FeatureItem("Медіа","Ліхтар","увімкнення та вимкнення","увімкни ліхтарик")
        ),
        "Продуктивність" to listOf(
            FeatureItem("Продуктивність","Таймер","природна тривалість","таймер на 5 хвилин"),
            FeatureItem("Продуктивність","Будильник","час у 24h форматі","будильник 07:30"),
            FeatureItem("Продуктивність","Подія","створення події календаря","створи подію зустріч"),
            FeatureItem("Продуктивність","Калькулятор","математичні вирази","порахуй 125*8"),
            FeatureItem("Продуктивність","Буфер обміну","читання / копіювання","прочитай буфер"),
            FeatureItem("Продуктивність","Поширення","системне меню Share","поділись привіт")
        ),
        "AI та голос" to listOf(
            FeatureItem("AI та голос","Gemini","складні запити та діалог","поясни квантову фізику"),
            FeatureItem("AI та голос","Пам'ять","зберігати факти за командою","запам'ятай мій проєкт"),
            FeatureItem("AI та голос","Hands‑free","діалог без постійного натискання","режим hands-free"),
            FeatureItem("AI та голос","Голоси","вибір Android TTS","відкрий голос")
        )
    )
    SimplePage("Функції COLD AI", onBack) {
        Text("Реальні Android-можливості", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
        Text("Команди можна запускати голосом або натисканням. Дії, що потребують дозволу, запитують його окремо.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        groups.forEach { (title, items) ->
            Text(title.uppercase(), Modifier.padding(top = 12.dp, bottom = 7.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
            items.forEach { f ->
                Surface(onClick = { vm.send(ctx, f.command) }, modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp), shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface, border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
                    Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(f.title, fontWeight = FontWeight.SemiBold); Text(f.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable private fun ChatScreen(vm: ColdVm, onTextPreset: (String) -> Unit, onMic: () -> Unit) {
    val messages by vm.messages.collectAsStateWithLifecycle(); val status by vm.status.collectAsStateWithLifecycle(); var text by remember { mutableStateOf("") }; val list = remember { androidx.compose.foundation.lazy.rememberLazyListState() }; val ctx = LocalContext.current
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) list.animateScrollToItem(messages.lastIndex) }
    Column(Modifier.fillMaxSize().padding(top = 58.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { ColdLogo(34.dp); Spacer(Modifier.width(9.dp)); Column(Modifier.weight(1f)) { Text("COLD AI", fontWeight = FontWeight.Bold); Text(if (status == Status.IDLE) "готовий" else status.name.lowercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary) } }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().widthIn(max = 820.dp).align(Alignment.CenterHorizontally).padding(horizontal = 14.dp), state = list, contentPadding = PaddingValues(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(messages, key = { it.id }) { m -> Message(m.text, m.role == "user") }
            if (status == Status.THINKING) item { TypingDots() }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.Bottom) {
            TextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text(stringResource(R.string.hint)) }, maxLines = 5, shape = RoundedCornerShape(22.dp))
            Spacer(Modifier.width(8.dp)); FilledIconButton({ if (text.isBlank()) onMic() else { vm.send(ctx, text); text = "" } }, Modifier.size(54.dp)) { Icon(if (text.isBlank()) Icons.Default.Mic else Icons.AutoMirrored.Filled.Send, null) }
        }
    }
}

@Composable private fun Message(text: String, user: Boolean) { Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) { Surface(Modifier.widthIn(max = 700.dp), shape = RoundedCornerShape(20.dp), color = if (user) MaterialTheme.colorScheme.primary.copy(.13f) else MaterialTheme.colorScheme.surface, border = if (user) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) { SelectionContainer { Text(text, Modifier.padding(14.dp), style = MaterialTheme.typography.bodyLarge) } } } }

@Composable private fun TypingDots() { val t = rememberInfiniteTransition(label = "dots"); Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) { repeat(3) { i -> val a by t.animateFloat(.2f, 1f, infiniteRepeatable(tween(500, delayMillis = i * 120), RepeatMode.Reverse), label = "d$i"); Box(Modifier.size(7.dp).alpha(a).background(MaterialTheme.colorScheme.primary, CircleShape)) } } }

@Composable private fun VoicePicker(vm: ColdVm, close: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle(); val ready by vm.voice.ttsReady.collectAsStateWithLifecycle(); val voices = remember(s.lang, ready) { vm.voice.voices(s.lang) }; val ctx = LocalContext.current
    ModalBottomSheet(onDismissRequest = close) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp).navigationBarsPadding()) {
            Text("Голос COLD AI", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Вибери голос, який доступний у TTS-рушії твого телефона.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(12.dp))
            LazyColumn(Modifier.heightIn(max = 390.dp)) {
                item { VoiceRow("За замовчуванням", s.voice.isEmpty(), { vm.prefs.update { it.copy(voice = "") }; vm.testVoice(ctx) }) }
                items(voices) { v -> VoiceRow(v.name, s.voice == v.name, { vm.prefs.update { it.copy(voice = v.name) }; vm.testVoice(ctx) }) }
            }
            Spacer(Modifier.height(12.dp)); Text("Швидкість", style = MaterialTheme.typography.labelLarge); Slider(s.rate, { vm.prefs.update { it.copy(rate = it) } }, .5f..2f)
            Text("Висота", style = MaterialTheme.typography.labelLarge); Slider(s.pitch, { vm.prefs.update { it.copy(pitch = it) } }, .5f..2f)
            Spacer(Modifier.height(12.dp)); Button(close, Modifier.fillMaxWidth()) { Text("Готово") }
        }
    }
}

@Composable private fun VoiceRow(name: String, selected: Boolean, click: () -> Unit) { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { click() }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Outlined.RecordVoiceOver, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(12.dp)); Text(name, Modifier.weight(1f)); if (selected) Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary) } }

@Composable private fun MemoryScreen(vm: ColdVm, onBack: () -> Unit) {
    val mem by vm.memories.collectAsStateWithLifecycle(); var text by remember { mutableStateOf("") }
    SimplePage("Пам'ять", onBack) { Row(verticalAlignment = Alignment.CenterVertically) { OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text(stringResource(R.string.memory_new)) }); Spacer(Modifier.width(8.dp)); Button({ vm.addMemory(text); text = "" }, enabled = text.isNotBlank()) { Text(stringResource(R.string.add)) } }; Spacer(Modifier.height(16.dp)); mem.forEach { m -> Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(15.dp), color = MaterialTheme.colorScheme.surface, border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Text(m.text, Modifier.weight(1f)); IconButton({ vm.deleteMemory(m.id) }) { Icon(Icons.Default.Delete, null) } } } }; if (mem.isNotEmpty()) OutlinedButton({ vm.clearMemories() }) { Text(stringResource(R.string.clear_all)) } }
}

@Composable private fun SettingsScreen(vm: ColdVm, onLang: (String) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current; val s by vm.settings.collectAsStateWithLifecycle(); var key by remember(s.apiKey) { mutableStateOf(s.apiKey) }; var model by remember(s.model) { mutableStateOf(s.model) }
    SimplePage(stringResource(R.string.settings), onBack) {
        SettingBlock("AI") { OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.api_key)) }, visualTransformation = PasswordVisualTransformation()); Spacer(Modifier.height(8.dp)); OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.model)) }); Spacer(Modifier.height(8.dp)); Button({ vm.prefs.update { it.copy(apiKey = key.trim(), model = model.trim()) } }) { Text(stringResource(R.string.save)) } }
        SettingBlock("Мова") { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(s.lang == "uk", { onLang("uk") }, { Text("Українська") }); FilterChip(s.lang == "ru", { onLang("ru") }, { Text("Русский") }) } }
        SettingBlock("Голос") {
            SwitchRow(stringResource(R.string.auto_speak), s.autoSpeak) { vm.prefs.update { it.copy(autoSpeak = it) } }
            SwitchRow("Hands-free діалог", s.handsFree) { vm.prefs.update { it.copy(handsFree = it) } }
            Text("Після відповіді COLD автоматично слухає наступну команду, поки застосунок відкритий.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Швидкість"); Slider(s.rate, { vm.prefs.update { it.copy(rate = it) } }, .5f..2f); Text("Висота"); Slider(s.pitch, { vm.prefs.update { it.copy(pitch = it) } }, .5f..2f); Button({ vm.testVoice(ctx) }) { Text(stringResource(R.string.voice_test_btn)) } }
        SettingBlock("Приватність") { SwitchRow(stringResource(R.string.save_history), s.saveHistory) { vm.prefs.update { it.copy(saveHistory = it) } }; SwitchRow(stringResource(R.string.use_memory), s.useMemory) { vm.prefs.update { it.copy(useMemory = it) } }; OutlinedButton({ vm.clearHistory() }) { Text(stringResource(R.string.clear_history)) } }
        SettingBlock("Тема") { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(s.theme == "system", { vm.prefs.update { it.copy(theme = "system") } }, { Text(stringResource(R.string.theme_system)) }); FilterChip(s.theme == "light", { vm.prefs.update { it.copy(theme = "light") } }, { Text(stringResource(R.string.theme_light)) }); FilterChip(s.theme == "dark", { vm.prefs.update { it.copy(theme = "dark") } }, { Text(stringResource(R.string.theme_dark)) }) } }
    }
}

@Composable private fun SimplePage(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) }; Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }; Spacer(Modifier.height(12.dp)); Column(Modifier.widthIn(max = 780.dp).align(Alignment.CenterHorizontally), content = content) } }

@Composable private fun SettingBlock(title: String, content: @Composable ColumnScope.() -> Unit) { Surface(Modifier.fillMaxWidth().padding(vertical = 7.dp), shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface, border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) { Column(Modifier.padding(18.dp), content = { Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp)); content() }) } }
@Composable private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f)); Switch(checked, onChange) } }
