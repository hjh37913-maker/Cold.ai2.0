# COLD AI — Voice Assistant

COLD AI is now designed primarily as a voice-first Android assistant. The home screen centers on a large animated microphone/orb; chat is secondary.

## Included local actions

The command router already contains 30+ local actions, including: memory, time/date, media controls, battery, volume, flashlight, device info, calculator, coin/dice/random, password generation, Google/Yandex search, camera, gallery, contacts, calendar, alarm, timer, email, WhatsApp, maps, clipboard, websites, Wi‑Fi/Bluetooth/sound/display/app/location/notification/date settings, app launching, phone calls and SMS with confirmation.

These actions are executed on the device and do not require a Gemini request. AI conversations still use the configured Gemini API and therefore require internet access.

## Voice

The app exposes the Android TTS voices installed on the phone. A voice can be selected from the home screen, tested immediately, and tuned by speech rate and pitch. The exact available voices depend on the installed TTS engine and language packs.

## Build APK

The project contains a GitHub Actions workflow at `.github/workflows/build-apk.yml`. Run it with **Actions → Build COLD AI APK → Run workflow**. The resulting debug APK is uploaded as the `COLD-AI-APK` artifact.

The source archive does not include the Gradle wrapper JAR, so this environment cannot build the APK locally. The workflow installs Gradle 8.7 on GitHub's Android runner.

## COLD // CORE — hands-free mode

The assistant now supports an optional foreground hands-free conversation mode. Tap the core once, speak naturally, and after each spoken answer COLD returns to listening. The mode is intentionally foreground-only; leaving the app stops listening.

The HUD exposes READY/LISTENING/THINKING/SPEAKING states, battery/network status, voice controls, memory, quick actions, and the existing local-command + Gemini routing.

## COLD // CORE v3 — Advanced Agent Layer

### Added
- Multi-step voice commands: `і потім`, `и потом`, `then`, `and then`.
- Native app discovery/launch by visible app name.
- Timers and alarms from natural-language commands.
- Calendar event creation through the native Android editor.
- Google and YouTube search by voice.
- Direct Wi-Fi/Bluetooth/Sound/Display settings panels.
- Optional Android Notification Listener integration: COLD can summarize recent notification titles after the user explicitly grants notification access.
- Safe local task routing happens before Gemini, reducing latency and API usage.
- Destructive/privacy-sensitive operations remain confirmation-gated.
- GitHub Actions builds with installed Gradle 8.7, so the missing wrapper JAR is no longer a blocker.

### Example commands
- `відкрий YouTube і потім відкрий Wi-Fi`
- `постав таймер на 5 хвилин`
- `будильник 07:30`
- `створи подію зустріч з командою`
- `пошукай в інтернеті ціни на ...`
- `відкрий YouTube коти`
- `які в мене сповіщення`

## COLD AI v5 — Product Layer

The UI now includes a dedicated feature center instead of presenting the assistant as a single AI demo screen. It exposes real Android capabilities by category: system controls, communications, media, productivity, AI/voice, notifications, clipboard, sharing, camera, calendar, alarms, timers, app launch, and search.

Additional local commands include opening phone/dialer, messaging, camera, gallery, calendar, contacts, battery settings, location, accessibility, notification settings, application info, clipboard read/copy, Android share, and volume percentage control. Unsupported actions remain routed to AI or to an explicit system settings panel rather than pretending they were completed.
